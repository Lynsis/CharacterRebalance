# maxplayers
#### modifies sv_maxplayers to modify maxPlayers internally

## How to Install
- Install Meepen's Mod Loader ([thunderstore.io](https://thunderstore.io/package/meepen/Meepens_Mod_Loader/) [github](https://github.com/meepen/ror2-modloader))
- Download and read the HOW TO INSTALL.txt

## How to Build
- Install [ror2-modloader](https://github.com/meepen/ror2-modloader)
- Download [premake5](https://github.com/premake/premake-core/releases)
- Run `premake5 vs2017` (for vs2017)
- Open the solution in the `project` folder
- Build the project
- Done!